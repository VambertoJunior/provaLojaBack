package shared.model.repository.service;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ImagemRepository extends JpaRepository<Imagem, Long> {
    @Query("SELECT i FROM Imagem i WHERE i.produto.id = :produtoId")
    List<Imagem> findByProdutoId(Long produtoId);
}