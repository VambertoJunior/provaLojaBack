package shared.model.repository.service;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "Produto")
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String nome;
    private Double preco;
    private String descricao;
    @OneToMany(mappedBy = "produto", cascade = CascadeType.ALL)
    private List<Imagem> imagens;

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {

        this.nome = nome;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public List<Imagem> getImagens() {
        return imagens;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setImagens(List<Imagem> imagens) {
        this.imagens = imagens;
    }
}
