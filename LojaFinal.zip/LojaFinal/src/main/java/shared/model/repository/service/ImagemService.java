package shared.model.repository.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;

@Service
public class ImagemService {

    @Autowired
    private ImagemRepository imagemRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    @Transactional
    public void uploadNovaImagem(Long id, MultipartFile imagemArquivo) {
        Produto produto = produtoRepository.findById(id).orElseThrow();
        Imagem novaImagem = new Imagem();
        novaImagem.setProduto(produto);
        imagemRepository.save(novaImagem);
    }

    @Transactional(readOnly = true)
    public List<Imagem> listarTodasAsImagensDeUmProduto(Long id) {
        produtoRepository.findById(id).orElseThrow();
        return imagemRepository.findByProdutoId(id);
    }

    @Transactional
    public void updateImagem(Long id, Imagem imagemAtualizada) {
        Imagem imagemExistente = imagemRepository.findById(id).orElseThrow();
        imagemRepository.save(imagemExistente);
    }

    @Transactional
    public void deleteImagem(Long imagemId) {
        Imagem imagemExistente = imagemRepository.findById(imagemId).orElseThrow();
        imagemExistente.getProduto().getImagens().remove(imagemExistente);
        imagemRepository.deleteById(imagemId);
    }

}