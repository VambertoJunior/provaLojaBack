package shared.model.repository.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    @Query("SELECT p FROM Produto p JOIN p.imagens i WHERE p.nome = :nome AND i IN :imagens AND p.preco = :preco")
    List<Produto> findByNomeAndImagensAndPreco(
            @Param("nome") String nome,
            @Param("imagens") List<Imagem> imagens,
            @Param("preco") double preco
    );
}
