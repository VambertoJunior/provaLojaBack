package shared.model.repository.service;

import jakarta.persistence.*;
@Entity
@Table(name = "Imagem")
public class Imagem {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String nome;
    private String url;
    @ManyToOne
    private Produto produto;

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getUrl() {
        return url;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }
}