package shared.model.repository.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    public Produto newProduto(Produto produto){
        return produtoRepository.save(produto);
    }

    public List<Produto> listar(){
        return produtoRepository.findAll();
    }

    public Produto updateProduto(Long id, Produto produtoAtualizado) {
        Optional<Produto> produtoExiste = produtoRepository.findById(id);

        if (produtoExiste.isPresent()) {
            Produto produto = produtoExiste.get();
            produto.setNome(produtoAtualizado.getNome());
            produto.setPreco(produtoAtualizado.getPreco());
            produto.setDescricao(produtoAtualizado.getDescricao());
            return produtoRepository.save(produto);
        } else {
            return null;
        }
    }

    public void deleteProduto(Long id) {
        produtoRepository.deleteById(id);
    }
}