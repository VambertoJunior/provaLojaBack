package com.vamberto.lojafinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaFinalApplication {

    public static void main(String[] args) {
        SpringApplication.run(LojaFinalApplication.class, args);
    }

}
