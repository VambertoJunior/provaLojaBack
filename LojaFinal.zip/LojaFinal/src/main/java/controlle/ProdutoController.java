package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import shared.model.repository.service.Produto;
import shared.model.repository.service.ProdutoService;

import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {

    @Autowired
    private ProdutoService produtoService;

    @GetMapping("/produto")
    public List<Produto> getProdutos() {
        return this.produtoService.listar();
    }

    @PostMapping("/produto")
    public Produto criarProduto(@RequestBody Produto produto) {
        return this.produtoService.newProduto(produto);
    }

    @PutMapping("/produto/{id}")
    public Produto atualizarProduto(@PathVariable("id") Long id, @RequestBody Produto produtoAtualizado) {
        return this.produtoService.updateProduto(id, produtoAtualizado);
    }

    @DeleteMapping("/produto/{id}")
    public void deleteProduto(@PathVariable("id") Long id) {
        this.produtoService.deleteProduto(id);
    }
}
