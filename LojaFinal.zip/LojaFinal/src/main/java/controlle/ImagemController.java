package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import shared.model.repository.service.Imagem;
import shared.model.repository.service.ImagemService;

import java.util.List;

@RestController
@RequestMapping("/imagem")
public class ImagemController {

    @Autowired
    private ImagemService imagemService;

    @PostMapping("/{id}")
    public void fazerUploadImagem(@PathVariable("id") Long id, @RequestParam("imagem") MultipartFile imagem) {
        this.imagemService.uploadNovaImagem(id, imagem);
    }

    @GetMapping("/{id}")
    public List<Imagem> listarImagensDoProduto(@PathVariable("id") Long id) {
        return this.imagemService.listarTodasAsImagensDeUmProduto(id);
    }

    @PutMapping("/imagem/{id}")
    public void atualizarImagem(@PathVariable("id") Long id, @RequestBody Imagem imagemAtualizada){
        this.imagemService.updateImagem(id, imagemAtualizada);
    }

    @DeleteMapping("/imagem/{id}")
    public void apagarImagem(@PathVariable("id") Long id)  {
        this.imagemService.deleteImagem(id);
    }
}